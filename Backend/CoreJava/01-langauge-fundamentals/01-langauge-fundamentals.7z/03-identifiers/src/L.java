class public
{
}