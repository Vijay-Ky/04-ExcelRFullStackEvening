class Hello100World
{
}