class _Hello_World_
{
}