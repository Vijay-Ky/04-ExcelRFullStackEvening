class $HelloWorld
{
}