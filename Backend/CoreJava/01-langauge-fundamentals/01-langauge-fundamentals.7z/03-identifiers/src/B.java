class 0HelloWorld
{
}