class _$Hello$World$_$
{
}