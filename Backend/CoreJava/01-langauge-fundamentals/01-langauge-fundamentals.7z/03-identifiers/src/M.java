class M 
{
	public static void main(String[] args) 
	{
		String NAME = "vijay";
		String name = "kumar";
		System.out.println(NAME);
		System.out.println(name);
	}
}
