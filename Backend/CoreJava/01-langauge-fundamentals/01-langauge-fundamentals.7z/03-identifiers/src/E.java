class !HelloWorld
{
}