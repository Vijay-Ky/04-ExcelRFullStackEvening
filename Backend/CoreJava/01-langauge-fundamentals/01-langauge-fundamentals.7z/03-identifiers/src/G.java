class $Hello$World$
{
}