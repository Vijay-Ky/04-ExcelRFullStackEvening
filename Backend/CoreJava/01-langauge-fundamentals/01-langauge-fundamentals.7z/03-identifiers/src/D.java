class Hello100World200
{
}