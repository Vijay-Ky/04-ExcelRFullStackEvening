class $
{
}