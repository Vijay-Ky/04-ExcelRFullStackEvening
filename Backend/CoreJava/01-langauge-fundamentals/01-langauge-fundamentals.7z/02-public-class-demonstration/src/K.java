class J
{
	public static void main(String[] args)
	{
		System.out.println("from J");
	}
}
public class K
{
	public static void main(String[] args)
	{
		System.out.println("from K");
	}
}
class L
{
	public static void main(String[] args)
	{
		System.out.println("from L");
	}
}